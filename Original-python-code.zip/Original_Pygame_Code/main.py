import pygame
import sys
import random
import math
import os

pygame.init()

# Set up display
width, height = 800, 600
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Py gaem")

# Load assets
background = pygame.image.load("background.jpg")
background = pygame.transform.scale(background, (width, height))

player = pygame.image.load("player.png")
player = pygame.transform.scale(player, (32, 32))

enemy_image = pygame.image.load("enemy.png")
enemy_image = pygame.transform.scale(enemy_image, (32, 32))

bullet_image = pygame.image.load("bullet.png")
bullet_image = pygame.transform.scale(bullet_image, (16, 16))

# Game objects
player_rect = player.get_rect()
player_rect.center = (width // 2, height // 2)
player_x = float(player_rect.x)
player_y = float(player_rect.y)

# Speeds
player_speed = 0.5
enemy_speed = 0.1
bullet_speed = 0.8

# Game state
enemies = []
bullets = []
score = 0
high_score = 0
font = pygame.font.SysFont(None, 36)

spawn_delay = 3000           # milliseconds
min_spawn_delay = 500        # milliseconds (min cap)
time_since_last_spawn = 0
time_to_decrease_delay = 10000  # every 10 seconds
time_since_last_decrease = 0

clock = pygame.time.Clock()
game_state = "start"

# High score file helpers
def load_high_score():
    try:
        with open("highscore.txt", "r") as f:
            return int(f.read())
    except:
        return 0

def save_high_score(score):
    try:
        with open("highscore.txt", "w") as f:
            f.write(str(score))
    except:
        pass

high_score = load_high_score()

# Game loop
running = True
while running:
    dt = clock.tick(60)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if game_state == "start":
                game_state = "playing"
                score = 0
                enemies = []
                bullets = []
                spawn_delay = 3000
                time_since_last_spawn = 0
                time_since_last_decrease = 0
                player_x = width // 2
                player_y = height // 2

            elif game_state == "gameover":
                game_state = "start"

            elif game_state == "playing":
                mx, my = pygame.mouse.get_pos()
                dx = mx - (player_x + player_rect.width / 2)
                dy = my - (player_y + player_rect.height / 2)
                distance = math.hypot(dx, dy)
                if distance == 0:
                    continue
                dx /= distance
                dy /= distance
                bullet_rect = bullet_image.get_rect()
                bullet_rect.center = (player_x + player_rect.width / 2, player_y + player_rect.height / 2)
                bullets.append([bullet_rect, float(bullet_rect.x), float(bullet_rect.y), dx, dy])

    screen.blit(background, (0, 0))

    if game_state == "start":
        title_text = font.render("Click to Start", True, (255, 255, 255))
        high_text = font.render(f"High Score: {high_score}", True, (255, 255, 0))
        screen.blit(title_text, (width // 2 - title_text.get_width() // 2, height // 2 - 30))
        screen.blit(high_text, (width // 2 - high_text.get_width() // 2, height // 2 + 10))

    elif game_state == "playing":
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            player_x -= player_speed * dt
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            player_x += player_speed * dt
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            player_y -= player_speed * dt
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            player_y += player_speed * dt

        player_x = max(0, min(player_x, width - player_rect.width))
        player_y = max(0, min(player_y, height - player_rect.height))
        player_rect.x = int(player_x)
        player_rect.y = int(player_y)

        if time_since_last_spawn >= spawn_delay:
            safe_distance = 150
            while True:
                enemy_rect = enemy_image.get_rect()
                enemy_rect.topleft = (
                    random.randint(0, width - enemy_rect.width),
                    random.randint(0, height - enemy_rect.height)
                )
                ex, ey = enemy_rect.center
                px, py = player_rect.center
                distance = math.hypot(ex - px, ey - py)
                if distance >= safe_distance:
                    break

            enemies.append([enemy_rect, float(enemy_rect.x), float(enemy_rect.y)])
            time_since_last_spawn = 0

        if time_since_last_decrease >= time_to_decrease_delay:
            spawn_delay = max(min_spawn_delay, spawn_delay - 150)  # decrease by 0.15 seconds (150 ms)
            time_since_last_decrease = 0

        time_since_last_spawn += dt
        time_since_last_decrease += dt

        for enemy in enemies:
            rect, ex, ey = enemy
            dx = player_x - ex
            dy = player_y - ey
            distance = math.hypot(dx, dy)
            if distance != 0:
                ex += (dx / distance) * enemy_speed * dt
                ey += (dy / distance) * enemy_speed * dt
            rect.x = int(ex)
            rect.y = int(ey)
            enemy[1] = ex
            enemy[2] = ey

        for enemy in enemies:
            if player_rect.colliderect(enemy[0]):
                game_state = "gameover"
                if score > high_score:
                    high_score = score
                    save_high_score(high_score)
                break

        for bullet in bullets[:]:
            rect, bx, by, dx, dy = bullet
            bx += dx * bullet_speed * dt
            by += dy * bullet_speed * dt
            rect.x = int(bx)
            rect.y = int(by)
            bullet[1] = bx
            bullet[2] = by

            if rect.right < 0 or rect.left > width or rect.bottom < 0 or rect.top > height:
                bullets.remove(bullet)
                continue

            for enemy in enemies[:]:
                if rect.colliderect(enemy[0]):
                    enemies.remove(enemy)
                    if bullet in bullets:
                        bullets.remove(bullet)
                    score += 1
                    break

        screen.blit(player, player_rect)
        for enemy in enemies:
            screen.blit(enemy_image, enemy[0])
        for bullet in bullets:
            screen.blit(bullet_image, bullet[0])

        score_text = font.render(f"Score: {score}", True, (255, 255, 255))
        screen.blit(score_text, (10, 10))

    elif game_state == "gameover":
        over_text = font.render("Game Over! Click to Restart", True, (255, 0, 0))
        score_text = font.render(f"Final Score: {score}", True, (255, 255, 255))
        high_text = font.render(f"High Score: {high_score}", True, (255, 255, 0))
        screen.blit(over_text, (width // 2 - over_text.get_width() // 2, height // 2 - 40))
        screen.blit(score_text, (width // 2 - score_text.get_width() // 2, height // 2 + 10))
        screen.blit(high_text, (width // 2 - high_text.get_width() // 2, height // 2 + 50))

    pygame.display.flip()

pygame.quit()
sys.exit()